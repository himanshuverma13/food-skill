import './App.css';
import RouteRoutes from './Components/Common/RouteRoutes/routes';
// import Home from '../src/Components/Pages/Home/home'

function App() {
  return (
    <>
    <div className='background-img'>
      {/* <Home/> */}
      <RouteRoutes/>
    </div>
    </>
  );
}

export default App;
